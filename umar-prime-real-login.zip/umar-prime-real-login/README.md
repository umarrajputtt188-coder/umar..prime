# Umar Prime — real login starter

This project includes a small Node.js backend and a responsive front end. Registration and login are real server requests; passwords are hashed with bcrypt and sessions are stored in SQLite. It is a starter project, not a finished production identity platform.

## Requirements

- Node.js 20 or newer
- npm

## Run locally

1. Extract the ZIP.
2. Open a terminal in this folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env`.
5. Set `SESSION_SECRET` to a long random secret (at least 32 characters). Do not publish `.env`.
6. Start the server:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000`.

## Important deployment notes

- GitHub Pages only hosts static files; it cannot run `server.js`. Deploy this whole project to a Node.js host that supports persistent storage, or use a managed authentication service.
- Use HTTPS in production and set `NODE_ENV=production`.
- Keep `.env`, the `data/` directory, and the SQLite database private and out of Git.
- Ensure your hosting provider has persistent disk storage for the SQLite user and session databases. If not, use a managed database and a compatible session store.
- Before production use, add email verification, password reset, CSRF protection appropriate to your deployment, backup/restore, monitoring, and a privacy policy.
- Do not collect financial account passwords, one-time codes, CNIC details, or biometric information in this demo.
- This code is an original starter implementation, not the source code of another website.
